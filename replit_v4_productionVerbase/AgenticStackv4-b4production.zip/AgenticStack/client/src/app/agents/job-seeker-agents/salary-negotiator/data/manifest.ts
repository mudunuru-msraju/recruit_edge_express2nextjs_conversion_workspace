export const agentManifest = {
  id: 'salary-negotiator',
  name: 'Salary Negotiator',
  category: 'job-seeker-agents',
  description: 'Research salaries and negotiate better offers',
  icon: 'DollarSign',
  color: 'teal',
  features: [],
  tags: [],
};
