/**
 * API Configuration for Skill Gap Analyzer
 * 
 * ⚠️ SECURITY WARNING - DEVELOPMENT ONLY ⚠️
 */

export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';
export const getMockUserId = () => '1';
