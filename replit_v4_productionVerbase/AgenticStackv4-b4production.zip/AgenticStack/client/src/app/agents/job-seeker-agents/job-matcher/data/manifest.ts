export const agentManifest = {
  id: 'job-matcher',
  name: 'Job Matcher',
  category: 'job-seeker-agents',
  description: 'Find jobs that match your skills and preferences',
  icon: 'Target',
  color: 'teal',
  features: [],
  tags: [],
};
