export const agentManifest = {
  id: 'job-description-generator',
  name: 'Job Description Generator',
  category: 'recruiter-agents',
  description: 'Create compelling job postings with AI assistance',
  icon: 'FileText',
  color: 'green',
  features: [],
  tags: [],
};
