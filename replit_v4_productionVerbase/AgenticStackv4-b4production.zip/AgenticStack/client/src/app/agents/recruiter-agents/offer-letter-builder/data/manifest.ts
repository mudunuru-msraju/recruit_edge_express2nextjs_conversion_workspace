export const agentManifest = {
  id: 'offer-letter-builder',
  name: 'Offer Letter Builder',
  category: 'recruiter-agents',
  description: 'Generate professional offer letters',
  icon: 'Mail',
  color: 'green',
  features: [],
  tags: [],
};
