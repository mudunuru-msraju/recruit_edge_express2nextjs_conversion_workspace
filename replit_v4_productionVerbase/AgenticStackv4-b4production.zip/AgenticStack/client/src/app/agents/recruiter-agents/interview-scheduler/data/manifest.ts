export const agentManifest = {
  id: 'interview-scheduler',
  name: 'Interview Scheduler',
  category: 'recruiter-agents',
  description: 'Schedule and manage interviews seamlessly',
  icon: 'Calendar',
  color: 'green',
  features: [],
  tags: [],
};
