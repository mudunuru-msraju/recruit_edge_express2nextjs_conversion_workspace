export const agentManifest = {
  id: 'talent-pipeline',
  name: 'Talent Pipeline',
  category: 'recruiter-agents',
  description: 'Manage and nurture candidate relationships',
  icon: 'Users',
  color: 'green',
  features: [],
  tags: [],
};
