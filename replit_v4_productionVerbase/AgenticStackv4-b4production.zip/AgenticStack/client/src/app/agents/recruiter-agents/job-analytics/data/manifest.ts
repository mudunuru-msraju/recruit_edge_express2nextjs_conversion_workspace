export const agentManifest = {
  id: 'job-analytics',
  name: 'Job Analytics',
  category: 'recruiter-agents',
  description: 'Track hiring metrics and performance',
  icon: 'BarChart',
  color: 'green',
  features: [],
  tags: [],
};
