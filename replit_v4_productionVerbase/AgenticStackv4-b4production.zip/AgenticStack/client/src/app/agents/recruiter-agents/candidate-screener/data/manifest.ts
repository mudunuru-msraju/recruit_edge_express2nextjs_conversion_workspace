export const agentManifest = {
  id: 'candidate-screener',
  name: 'Candidate Screener',
  category: 'recruiter-agents',
  description: 'Screen and evaluate candidates efficiently',
  icon: 'UserCheck',
  color: 'green',
  features: [],
  tags: [],
};
