export const agentManifest = {
  id: 'audit-logger',
  name: 'Audit Logger',
  category: 'admin-agents',
  description: 'Track and review system audit logs',
  icon: 'FileSearch',
  color: 'teal',
  features: [],
  tags: [],
};
