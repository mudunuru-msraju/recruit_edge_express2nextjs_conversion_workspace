export const agentManifest = {
  id: 'content-moderator',
  name: 'Content Moderator',
  category: 'admin-agents',
  description: 'Review and moderate flagged content',
  icon: 'Shield',
  color: 'teal',
  features: [],
  tags: [],
};
