export const agentManifest = {
  id: 'billing-manager',
  name: 'Billing Manager',
  category: 'admin-agents',
  description: 'Track subscriptions and revenue',
  icon: 'CreditCard',
  color: 'teal',
  features: [],
  tags: [],
};
