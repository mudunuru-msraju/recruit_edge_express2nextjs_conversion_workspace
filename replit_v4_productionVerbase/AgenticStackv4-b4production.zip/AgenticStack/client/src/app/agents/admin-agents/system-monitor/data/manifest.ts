export const agentManifest = {
  id: 'system-monitor',
  name: 'System Monitor',
  category: 'admin-agents',
  description: 'Monitor system health and performance',
  icon: 'Activity',
  color: 'teal',
  features: [],
  tags: [],
};
