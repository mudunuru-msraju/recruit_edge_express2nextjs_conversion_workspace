export const agentManifest = {
  id: 'user-management',
  name: 'User Management',
  category: 'admin-agents',
  description: 'Manage users, roles, and permissions',
  icon: 'Users',
  color: 'teal',
  features: [],
  tags: [],
};
