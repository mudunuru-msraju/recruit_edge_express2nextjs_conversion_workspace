export const agentManifest = {
  id: 'platform-analytics',
  name: 'Platform Analytics',
  category: 'admin-agents',
  description: 'Monitor platform-wide metrics and trends',
  icon: 'TrendingUp',
  color: 'teal',
  features: [],
  tags: [],
};
